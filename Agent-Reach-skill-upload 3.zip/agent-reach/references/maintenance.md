# Maintenance

Read this when an update fails, the browser won't start, a channel reports an error, or the user wants to uninstall.

- Update: `agent-reach update` upgrades Agent Reach, the tools of every added channel, and the skill. `agent-reach update --check` only checks whether a new version exists. Run the update only with the user's consent.
- Status: `agent-reach doctor --text` reads local status and makes no network calls. `agent-reach check <channel> --text` runs one live test over the network (`--search` tests only search and job listings). A successful install does not mean the live test has passed.
- Browser: `agent-reach browser status` shows the status, `browser setup` prepares the engine and extension, and `browser stop` closes it. If the CloakBrowser download failed, fix the network first, then run `browser setup --retry-cloak`.
- Find the failing stage: dependency download, browser connection, login, page loading, and platform rate limits are separate problems. Do not describe a network timeout as an expired login.
- Upstream tool errors: note the error and the version, then run `agent-reach update` once with the user's consent. Do not edit the upstream tool's installed files, and do not retry in a loop.
- `PLATFORM_BLOCKED`, `RATE_LIMITED`, `NEED_LOGIN`, and `BUSY` mean stop this attempt, and continue only after the user has dealt with it. Do not open windows repeatedly.
- Keys and proxies: `agent-reach configure groq-key | openai-key | proxy | github-token`. The user provides the values personally.
- Port conflict (`Port <n> belongs to an unmanaged browser`): another program is using the dedicated browser's port (default 9222). Do not close the user's program. With the user's consent, run `agent-reach configure browser-port <free port>`.
- Uninstall: first run `agent-reach uninstall --dry-run` and show the user the scope; after confirmation, run `agent-reach uninstall`. It removes only what Reach itself installed; the user's other files and browsers are kept.
