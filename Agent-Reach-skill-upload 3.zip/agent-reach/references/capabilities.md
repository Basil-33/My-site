# Capability scope

Read this when the user asks what can be looked up or how complete the results are, or when you need to judge how complete a result is. The table below lists declared capabilities; it does not guarantee that every network, account, or piece of content has been tested.

## Three layers

- **Public routes to try**: the agent's built-in web tools, native tools, or public interfaces may already satisfy the task; no browser or login is required. Answer based on the evidence actually obtained.
- **Reach additions**: the actions declared by the current release; see `agent-reach channels`. When configuration is needed, first reuse the session already saved in the dedicated browser, and only have the user log in personally if the chosen route actually requires it.
- **Verified locally**: lists only the specific actions that passed the most recent local acceptance test. A successful install, a saved session, or network reachability does not equal business acceptance.

## Channels in this release

| Channel | Public routes to try | Reach additions and limits |
|---|---|---|
| GitHub | Public repositories, READMEs, issues and PRs | Repository search, reading repositories, issues, and PRs, and the comments they return; private access is judged separately |
| YouTube | Search, titles, and descriptions; native tools may obtain some comments and subtitle text | search/read/subtitle/transcribe; there is currently no unified comments action; a track list is not subtitle text, and without subtitles, transcription depends on the corresponding tool |
| Bilibili | Search and descriptions; some public interfaces return comments and parent-child IDs | search/read/hot/subtitle; there is currently no unified comments action; subtitles vary by video and access route |
| Reddit | Search, post bodies, some comments; some public JSON may include parent-child IDs | Browser-based search/read/subreddit; whether login is needed depends on the chosen route; the full comment tree and all replies are not guaranteed; posting comments is not provided |
| X/Twitter | Public single posts returned by search; some official public embeds return full text | search/profile/tweets/thread; a readable single post does not mean the reply stream is readable; the full comment tree is not guaranteed |
| Xiaohongshu | Public lists or indexes may include note IDs, authors, and titles; empty fields must not be guessed | search/read/comments; text descriptions, top-level comments, and loaded replies; not all comments are guaranteed; does not claim to understand images or videos |
| Instagram | Some indexes and shallow profile information; an HTML app shell does not count as a post | search finds users, profile shows profiles, posts describes a given user's posts; there is no unified comments action; does not claim to understand images or videos |
| Facebook | Some indexes or HTML summaries; summaries may be truncated | search/profile; there is no unified detail or comments action; a search summary must not be treated as full text |
| LinkedIn | Search public job listings and read public job descriptions | jobs/read try public web pages first; the opencli option goes directly on-site; not all listings are guaranteed to be readable |
| BOSS (Zhipin) | Job summaries may appear in search indexes | search/read for job lists and job descriptions; never guess salary figures from encoded salary data; fallback detail capabilities depend on what the channel declares |
| V2EX | Topics, bodies, and public replies | hot/node/read/user; the scope returned depends on this response; hidden or missing replies are not guaranteed |
| Xueqiu | Some public quotes and index information | quote/search/hot_posts/hot_stocks; quotes and community routes are verified separately |
| Web | The agent's built-in search and read | Reach web search/read is the anonymous fallback; summaries, page shells, and verification pages must not be treated as complete body text |
| Xiaoyuzhou | Episode page titles and descriptions | transcribe converts a whole episode to text; requires a Groq key from the user (`agent-reach configure groq-key`) |

For capabilities after logging in, use "can enable / try the browser actions above", not "supports all comments after login". If the user skips logging in, deliver the public evidence already obtained.
