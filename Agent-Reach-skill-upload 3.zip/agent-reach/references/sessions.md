# Sessions and the dedicated browser

Read this when the user wants to log in, log out, or switch accounts, or when a result returns `NEED_LOGIN`.

## The dedicated browser

- All browser channels share one dedicated browser profile, separate from the user's everyday Chrome. The program never closes or modifies the user's everyday browser.
- The engine is CloakBrowser when possible. If its download or install fails, the program uses the locally installed Chrome and remembers this fallback instead of downloading again every time. After the network is fixed, `agent-reach browser setup --retry-cloak` can retry.
- `agent-reach add <channel>` automatically prepares Node, OpenCLI, the engine, and the extension. Tools are installed at the versions tested for this release. On Windows, when falling back to Chrome, the user may need to click "Add to Chrome" once.
- It runs headless by default and shows no window. Only `agent-reach login <channel>` displays a window. While that window is open, queries use this window directly and do not close it; while the user is logging in, wait until they say they have finished before querying. After the window is closed, later queries return to headless mode.
- It closes automatically after 10 minutes idle and reopens automatically on the next call. Real page actions and Reach calls reset the timer. During login it saves periodically, so the user does not need to close the window.
- Parallel use is allowed: at most 2 concurrent calls per platform and 4 across all platforms; extra calls queue, waiting at most 2 minutes before returning `BUSY`. Two searches on the same platform must be at least 10 seconds apart. Opening a login window, logging out, or reinstalling the browser waits for running queries to finish first.
- `agent-reach browser status` shows the status, `browser setup` prepares the engine and extension, and `browser stop` closes the browser the program manages.

## Automatically reusing an existing login

1. The first time a site is used, if the user's Chrome has the OpenCLI extension connected, the program copies that site's login (cookies for that site only) into the dedicated browser once. It does not copy the whole browser profile, other sites, or the password manager, and it does not modify the source browser.
2. After a successful copy, the saved session is reused and is not copied again on a schedule. A cookie existing does not prove the login is valid; the result of the real action is what counts.
3. If the user's Chrome does not have the extension connected, do not promise automatic reuse, and do not conclude the user is logged out because of that. Use the session Reach already saved instead.
4. If several local browsers are logged in to the site, use `agent-reach browser profiles` to list the sources, then `agent-reach browser use <ID>` to choose one. Do not switch between them at random.
5. `agent-reach login <channel> --import-existing` copies the site's login again on purpose, without opening a window. If no copyable login is found, or the OpenCLI Bridge is not running, it returns `NEED_SETUP`, and the saved session is unchanged.
6. If the user logged in personally in the dedicated window, or ran `logout` or `remove`, automatic copying stops, so a login the user already ended does not come back.

## When the user must log in personally

- Ask the user to log in only when the result actually returns `NEED_LOGIN` and the remaining task really needs that path. A login button next to the body text does not count as a login requirement.
- `agent-reach login <channel>` opens the dedicated browser to the site's login page, and the user completes the login personally. You never log in for them, never ask for a password, and never output cookies.
- If the returned `next` field lists follow-up steps, follow them. For some native-tool channels (such as Xueqiu), run `agent-reach login <channel> --sync` after logging in.
- Once the user is done, rerun the original action to verify.

## Platform differences

- Boss Zhipin on-site search goes through OpenCLI and shares the dedicated browser. If a job detail page wrongly reports a login requirement because of an upstream false alarm, do not make the user log in repeatedly.
- Bilibili hands the existing login to Bilibili's official command-line tool only when reading subtitles; ordinary search does not prepare a browser.
- Xueqiu community actions require login, and the session expires within a few hours. After it expires, repeat the login steps.

## Logout and removal

- `agent-reach logout <channel>` clears that site's login in the dedicated browser and the channel's own state. Other sites are kept.
- `agent-reach remove <channel>` removes the channel and also clears that site's login and storage. Other sites are kept. If cleanup fails, the channel record is kept and an error is returned, and the user can retry.
- After either command, the site's login is no longer copied automatically.
